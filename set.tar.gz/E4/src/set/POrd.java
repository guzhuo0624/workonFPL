package set;

import java.util.List;

public abstract class POrd<T> implements Eq<T>{
	
	public abstract POrdering pcompare(T other);
	
	public boolean eq(T other) {
		if (this.pcompare(other) == POrdering.PEQ) {
			return true;
		} else {
			return false;
		}
	}
	
	public boolean lt(T other) {
		if (this.pcompare(other) == POrdering.PLT) {
			return true;
		} else {
			return false;
		}
	}
	
	public boolean gt(T other) {
		if (this.pcompare(other) == POrdering.PGT) {
			return true;
		} else {
			return false;
		}
	}
	
	public boolean lte(T other) {
		return (this.pcompare(other) == POrdering.PLT || this.pcompare(other) == POrdering.PEQ);
	}
	
	public boolean gte(T other) {
		return !lt(other);
	}
	
	public boolean inc(T other) {
		return this.pcompare(other) == POrdering.PIN;
	}
}
