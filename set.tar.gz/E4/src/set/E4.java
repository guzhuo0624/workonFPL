package set;

import java.util.ArrayList;
import java.util.List;

public class E4 {

    public static void main(String[] args) {
        Set<MyInt> emptyset = new Set<>(new ArrayList<MyInt>());
        
        List<MyInt> sngle = new ArrayList<>();
        sngle.add(new MyInt(42));
        Set<MyInt> singleton = new Set<>(sngle);

        List<MyInt> sl = new ArrayList<>();
        for (int i = 1; i < 4; i++) {
            sl.add(new MyInt(i));
        }
        Set<MyInt> s = new Set<>(sl);
        
        List<MyInt> tl = new ArrayList<>();
        for (int i = 1; i < 5; i++) {
            tl.add(new MyInt(i));
        }
        Set<MyInt> t = new Set<>(tl);
    
        System.out.println("{} < {42}? " + emptyset.lt(singleton));
        System.out.println("{42} <= {1,2,3}? " + singleton.lte(s));
        System.out.println("{1,2,3,4} >= {1,2,3}? " + t.gte(s));
        System.out.println("{1,2,3} ? {1,2,3,4}? " + s.pcompare(t));
        System.out.println("{1,2,3} ? {42}? " + s.pcompare(singleton));
        
        /* Expected output:
         * {} < {42}? true
         * {42} <= {1,2,3}? false
         * {1,2,3,4} >= {1,2,3}? true
         * {1,2,3} ? {1,2,3,4}? PLT
         * {1,2,3} ? {42}? PIN
         */
    }
}

class MyInt implements Eq<MyInt>, Show {
    private Integer i;
    
    public MyInt(Integer i) {
        this.i = i;
    }
    
    public Integer getInt() {
        return i;
    }

    @Override
    public boolean eq(MyInt other) {
        return i.equals(other.getInt());
    }

    @Override
    public String show() {
        return String.valueOf(i);
    }
}
