package set;

import java.util.List;

public class Set<E extends Eq<E>> extends POrd<Set<E>> implements Show{
	private List<E> elements;
	
	public List<E> getElements() {return elements;}

	@Override
	public String show() {
		// TODO Auto-generated method stub
		return "Set: " + elements.toString();
	}

	public Set(List<E> i){
		this.elements = i;
	}
	
	public boolean con(Set<E> other){
		for (int i = 0; i < other.elements.size(); ++i) {
			boolean found = false;
			for (int j = 0; j < this.elements.size(); ++j) {
				if (other.elements.get(i).eq(this.elements.get(j))) {
					found = true;
				}
			}
			if (found == false) return false;
		}
		return true;
	}
	
	@Override
	public POrdering pcompare(Set<E> other) {
		if (this.elements.size() == other.elements.size() &&
			this.con(other)) {
			return POrdering.PEQ;
		} else if (this.elements.size() < other.elements.size() &&
				   other.con(this)) {
			return POrdering.PLT;
		} else if (this.elements.size() > other.elements.size() &&
				   this.con(other)) {
			return POrdering.PGT;
		} else {
			return POrdering.PIN;
		}
	}
}

