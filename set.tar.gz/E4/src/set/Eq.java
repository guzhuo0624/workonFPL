package set;

public interface Eq<T> {
	public boolean eq(T other);
}
