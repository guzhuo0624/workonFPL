package set;

public interface Show {
	
	public String show();
	
}
