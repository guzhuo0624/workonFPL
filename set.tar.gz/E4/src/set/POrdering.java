package set;

public enum POrdering {
    PLT, PEQ, PGT, PIN;
}